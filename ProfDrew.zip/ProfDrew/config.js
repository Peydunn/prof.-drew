module.exports = {
    'token': '',
    'nickname': 'Professor Drew',
    'activity': 'Primal Moon',
    'prefix': '!',
    'ticketParentChannel': '469251649471250432',
    'ticketCategory': '469251649471250432',
    'submissionChannels': ['593634365213245450', '582678435420438531', '486048422256967681'],
    'reactionEmotes': ['👍', '👎'],
}